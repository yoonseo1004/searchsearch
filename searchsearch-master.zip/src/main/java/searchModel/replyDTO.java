package searchModel;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class replyDTO {

	private int clNum;
	private String userId;
	private String content;
}
